from django.shortcuts import render
from django.http import Http404, HttpResponse, HttpResponseNotFound, HttpResponseRedirect
from django.urls import reverse
from django.template.loader import render_to_string


monthly_challenges_dict = {
    "january": "Eat no meat for entire month!",
    "february":"Walk for 20 minutes everyday!",
    "march":"Join the gym and do the resistance training",
    "april":"Read one book for every week",
    "may":"Drink no soda for entire month",
    "june":"Wake up early for every morning",
    "july":"Try new food for every single week",
    "august":"Write one page for every single day",
    "september":"Meditate daily for entire month",
    "october":"Practice gratitude for every single day",
    "november":"Limit screen time for every single day",
    "december": None
}

def index(request):
    list_items = ""
    months = list(monthly_challenges_dict.keys())

    return render(request,"challenges/index.html",{
        "months": months
    })
    # for month in months:
    #     capitalized_month = month.capitalize()
    #     month_path = reverse("month-challenge", args=[month])
    #     list_items += f"<li><a href=\"{month_path}\">{capitalized_month}</a></li>"

    ## "<li><a href ="...:">January</li><li<a href ="...:">February</li>...."

    response_data = f"<ul>{list_items}</ul>"
    return HttpResponse(response_data)
    
def monthly_challenges_by_numbers(request, month):
    months = list(monthly_challenges_dict.keys())

    if month > len(months):
        return HttpResponseNotFound("Invalid Month")
    
    redirect_month = months[month - 1]
    redirect_path = reverse('month-challenge',args=[redirect_month]) # /challenge/january
    return HttpResponseRedirect(redirect_path)


def monthly_challenges(request, month):
    try:
        challenge_text = monthly_challenges_dict[month.lower()]
        return render(request,"challenges/challenges.html", {
            "text": challenge_text,
            "month": month
        })
    except:
        raise Http404()   

